package com.mygdx.game.entety;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Boss extends Entety{
    @Override
    public void draw(SpriteBatch batch) {

    }

    @Override
    public void update() {

    }
}
