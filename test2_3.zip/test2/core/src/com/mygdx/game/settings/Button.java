package com.mygdx.game.settings;

public class Button {
}
